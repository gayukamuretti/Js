// alert("FROM VALIDATION");

document.getElementById("name").addEventListener('keyup', user);
document.getElementById("email").addEventListener('keyup', mail);
document.getElementById("password").addEventListener('keyup', password);
document.getElementById("phone").addEventListener('keyup', phone);
document.getElementById("location").addEventListener('change', native);
document.getElementById("seasons").addEventListener('click', season);
document.getElementById("agree").addEventListener('click', checkbox);
document.getElementById("submit").addEventListener('click', submit);

// Toastr
toastr.options = {
    "closeButton": true,
    "debug": false,
    "newestOnTop": false,
    "progressBar": true,
    "positionClass": "toast-top-right",
    "preventDuplicates": true,
    "onclick": null,
    "showDuration": 800,
    "hideDuration": 1000,
    "timeOut": 5000,
    "extendedTimeOut": 1000,
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
}

function submit(e){
    e.preventDefault();
    user();
    mail();
    password();
    phone();
    native();
    season();
    checkbox();
   
    var result = user() && mail() && password() && phone()  && native() && season()  && checkbox();
    if (result == "true") {
        toastr.success("Form filled successfully.");
    }
    else{
        toastr.error("Please fill all the  fields.");
    }
};
 

// name function()
function user(){
    var user = document.getElementById("name");
    var username = user.value;
    var pattern = /^[0-9{.@$/%^&*(). !}]+$/;
    if(username == ""){
        document.getElementById("nameerr").innerHTML = "*Please fill your name.";  
        document.getElementById("name").classList.add("is-invalid");
        document.getElementById("name").classList.remove("is-valid");
        document.getElementById("nameerr").style.color = "#FF7F50"; 
    }
    else if(username.match(pattern)){
        document.getElementById("nameerr").innerHTML = "*Only alphabets are allowed numeric and special characters not accepted.";  
        document.getElementById("name").classList.add("is-invalid"); 
        document.getElementById("nameerr").style.color = "#FF7F50"; 
    }
    else{
        document.getElementById("nameerr").innerHTML = "Valid";  
        document.getElementById("name").classList.add("is-valid");  
        document.getElementById("name").classList.remove("is-invalid");
        document.getElementById("nameerr").style.color = "#2ecc71";
        return 'true';
    }
}
       
// mail function()
    function mail(){
    var mail = document.getElementById("email");
    var mailvalue = mail.value;
    var idpattern = /^([a-z0-9_.])+\@([A-z])+\.([a-z])+$/;
    if(mailvalue == ""){
        document.getElementById("mailerr").innerHTML = "*Please fill your Email.";  
        document.getElementById("email").classList.add("is-invalid");
        document.getElementById("email").classList.remove("is-valid");
        document.getElementById("mailerr").style.color = "#FF7F50"; 
    }
    else if(mailvalue.match(idpattern)){
        document.getElementById("mailerr").innerHTML = "Valid";  
        document.getElementById("email").classList.add("is-valid"); 
        document.getElementById("email").classList.remove("is-invalid");
        document.getElementById("mailerr").style.color = "#2ecc71"; 
        return 'true';
    }
    else{
        document.getElementById("mailerr").innerHTML = "* @ or .com may be missing.";  
        document.getElementById("email").classList.add("is-invalid");  
        document.getElementById("mailerr").style.color = "#FF7F50";
    }
}

// Password function()
    function password(){
    var password = document.getElementById("password");
    var passwordValue = password.value;
    var passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$/;
    if(passwordValue == ""){
        document.getElementById("passworderr").innerHTML = "*Please set the password.";  
        document.getElementById("password").classList.remove("is-valid");
        document.getElementById("password").classList.add("is-invalid");
        document.getElementById("passworderr").style.color = "#FF7F50"; 
    }
    else if(passwordValue.match(passwordPattern)){
        document.getElementById("passworderr").innerHTML = "Valid";  
        document.getElementById("password").classList.add("is-valid"); 
        password.classList.remove("is-invalid"); 
        document.getElementById("password").getElementById("passworderr").style.color = "#2ecc71"; 
        return 'true';
    }
    else if(passwordValue.length >= 8){
        document.getElementById("passworderr").innerHTML = "valid";  
        document.getElementById("password").classList.add("is-valid"); 
        document.getElementById("password").classList.remove("is-invalid");
        document.getElementById("passworderr").style.color = "#2ecc71"; 
        return 'true';

    }
}

// Phone function()
function phone(){
    var phone = document.getElementById("phone");
    var number = phone.value;
    var pattern = /^([0-9]{10})+$/;
    if(number == ""){
        document.getElementById("phoneerr").innerHTML = "*Please fill your phone number.";  
        document.getElementById("phone").classList.add("is-invalid");
        document.getElementById("phone").classList.remove("is-valid"); 
        document.getElementById("phoneerr").style.color = "#FF7F50";
    }
    else if(number.match(pattern)){
        document.getElementById("phoneerr").innerHTML = "Valid";  
        document.getElementById("phone").classList.add("is-valid"); 
        document.getElementById("phone").classList.remove("is-invalid"); 
        document.getElementById("phoneerr").style.color = "#2ecc71"; 
        return 'true';
    }
    else{
        document.getElementById("phoneerr").innerHTML = "*Please fill 10 digits.";  
        document.getElementById("phone").classList.add("is-invalid");  
        document.getElementById("phoneerr").style.color = "#FF7F50";
        error++;
    }
}

//select function()
document.getElementById("location").addEventListener('change', native);
function native() {
    var place = document.getElementById("location").value;
    if (place == "") {
        document.getElementById("placeerr").innerHTML = "*Please select your place.";
        document.getElementById("location").classList.add("is-invalid"); 
        document.getElementById("location").classList.remove("is-valid"); 
        document.getElementById("placeerr").style.color = "#FF7F50";
    } else {
        document.getElementById("placeerr").innerHTML = "Selected";
        document.getElementById("location").classList.add("is-valid"); 
        document.getElementById("location").classList.remove("is-invalid"); 
        document.getElementById("placeerr").style.color = "#2ecc71";
        return 'true';
    }
}

// radiobox function()
function season() {
    var getSelectedValue = document.querySelector('input[name="seasons"]:checked');
    if (getSelectedValue != null) {
        document.getElementById("seasonerr").innerHTML = "Selected";
        document.getElementById("seasons").classList.add("is-valid"); 
        document.getElementById("seasons").classList.remove("is-invalid"); 
        document.getElementById("seasonerr").style.color = "#2ecc71";
        return 'true';
    } else {
        document.getElementById("seasonerr").innerHTML = "*Please select any season.";
        document.getElementById("seasons").classList.add("is-invalid"); 
        document.getElementById("seasons").classList.remove("is-valid"); 
        document.getElementById("seasonerr").style.color = "#FF7F50";
    }

}



// Checkbox function()
function checkbox(){
    // console.log("agree");
    var checkbox = document.getElementById("agree").checked;
    if(checkbox == 0){
        document.getElementById("termserr").innerHTML = "*Please accept terms and conditions"; 
        document.getElementById("agree").classList.add("is-invalid");  
        document.getElementById("termserr").style.color = "#FF7F50";
        // error++;
    }
    else{
        document.getElementById("termserr").innerHTML = "Checked"; 
        document.getElementById("agree").classList.add("is-valid");  
        document.getElementById("agree").classList.remove("is-invalid");
        document.getElementById("termserr").style.color = "#2ecc71";
        return 'true';
    }
}

// Reset function()
function reset(){
    document.getElementById("form").reset();
}

 





  
  