
var id="Id",per_name="Name",desig="Position",salary="salary",
per1_id="10",per1_name="Karthi",per1_desig="Manager",per1_salary="450000",
per2_id="20",per2_name="Agash",per2_desig="Staff",per2_salary="100000";


document.getElementById("id").innerHTML = id;
document.getElementById("name").innerHTML = per_name;
document.getElementById("desig").innerHTML =desig;
document.getElementById("salary").innerHTML = salary;

document.getElementById("emp1-id").innerHTML = per1_id;
document.getElementById("emp1-name").innerHTML = per1_name;
document.getElementById("emp1-desig").innerHTML =per1_desig;
document.getElementById("emp1-salary").innerHTML = per1_salary;

document.getElementById("emp2-id").innerHTML = per2_id;
document.getElementById("emp2-name").innerHTML = per2_name;
document.getElementById("emp2-desig").innerHTML =per2_desig;
document.getElementById("emp2-salary").innerHTML = per2_salary;