alert("Timer")
// declaring the varibles
var data = 0;
  
document.getElementById("decrement").addEventListener("click",decrement);
document.getElementById("reset").addEventListener("click",reset);
document.getElementById("increment").addEventListener("click",increment);

//creation of decrement function
decrement.addEventListener("click",function(){
    data = data - 1;
    document.getElementById("num").innerHTML= data;
    document.getElementById("num").style.color = 'red';
});

//reset function
reset.addEventListener("click",function(){
    data = 0;
    document.getElementById("num").innerHTML = data;
    document.getElementById("num").style.color = 'gray';

});

//increment function
increment.addEventListener("click",function(){
    data = data + 1;
    document.getElementById("num").innerHTML = data ;
    document.getElementById("num").style.color = 'green';
});


